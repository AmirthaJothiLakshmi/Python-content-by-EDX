# MITx-6.00.1x
Coding exercises and Problem Sets for MITx: 6.00.1x Introduction to Computer Science and Programming Using Python, EdX, Aug-Nov 2016

All code in this course uses Python 3.x.
