# Exercise: for exercise 1

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 5 minutes

# In this problem you'll be given a chance to practice writing some for loops.

# 1. Convert the following code into code that uses a for loop.

# prints 2
# prints 4
# prints 6
# prints 8
# prints 10
# prints "Goodbye!"

None

for i in range(2, 11, 2):
    print(i)
print('Goodbye!')

# Correct
