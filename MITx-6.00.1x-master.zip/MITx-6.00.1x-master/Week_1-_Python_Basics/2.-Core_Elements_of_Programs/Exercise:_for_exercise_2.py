# Exercise: for exercise 2

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 5 minutes

# 2. Convert the following code into code that uses a for loop.

# prints "Hello!"
# prints 10
# prints 8
# prints 6
# prints 4
# prints 2


None

print('Hello!')
for i in range(10, 0, -2):
    print(i)

# Correct
