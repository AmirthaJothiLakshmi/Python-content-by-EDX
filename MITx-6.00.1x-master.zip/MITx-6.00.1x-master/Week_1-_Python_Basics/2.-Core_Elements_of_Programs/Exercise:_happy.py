# Exercise: happy

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 3 minutes

# Write a piece of Python code that prints out the string 'hello world' if the value of an integer variable, happy, is strictly greater
# than 2.

None
if happy > 2:
    print('hello world')
