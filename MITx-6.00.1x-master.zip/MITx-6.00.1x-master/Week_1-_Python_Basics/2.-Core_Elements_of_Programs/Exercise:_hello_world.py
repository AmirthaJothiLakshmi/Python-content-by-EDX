# Write a piece of Python code that prints out the string hello world

None
print("hello world")
