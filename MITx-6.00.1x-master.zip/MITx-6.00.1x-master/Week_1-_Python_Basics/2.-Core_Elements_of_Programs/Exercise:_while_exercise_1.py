# Exercise: while exercise 1

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 5 minutes

# In this problem you'll be given a chance to practice writing some while loops.

# 1. Convert the following into code that uses a while loop.

# print 2
# prints 4
# prints 6
# prints 8
# prints 10
# prints Goodbye!


None

x = 2
while x < 11:
    print(x)
    x += 2
print('Goodbye!')
