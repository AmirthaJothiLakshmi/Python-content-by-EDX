# Exercise: while exercise 2

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 5 minutes

# 2. Convert the following into code that uses a while loop.

# prints Hello!
# prints 10
# prints 8
# prints 6
# prints 4
# prints 2


None

y = 10
print('Hello!')
while y > 0:
    print(y)
    y -= 2

# Correct
