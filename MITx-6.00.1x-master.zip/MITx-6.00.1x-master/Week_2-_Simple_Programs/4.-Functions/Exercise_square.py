# Exercise: square

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 3 minutes

# Write a Python function, square, that takes in one number and returns the square of that number.

# This function takes in one number and returns one number.


def square(x):
    '''
    x: int or float.
    '''
    # Your code here
    return x**2

# Correct
