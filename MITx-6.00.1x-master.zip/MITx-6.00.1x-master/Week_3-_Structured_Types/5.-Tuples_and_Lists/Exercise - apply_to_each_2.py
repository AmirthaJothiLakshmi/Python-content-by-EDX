# Exercise: apply to each 2

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 4 minutes


# Your Code Here
def addOne(b):
        return b + 1

applyToEach(testList, addOne)

# [1, -4, 8, -9]
# Correct
