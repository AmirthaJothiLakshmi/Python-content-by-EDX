# Exercise: apply to each 3

# (5/5 points)
# ESTIMATED TIME TO COMPLETE: 4 minutes


# Your Code Here
def squared(c):
    return c**2

applyToEach(testList, squared)
# Correct
